/*
 * button.h
 *
 *  Created on: Sep 9, 2024
 *      Author: kishan.shivhare
 */

#ifndef BUTTON_H_
#define BUTTON_H_
#include "stm32f1xx_hal.h"
#include "fonts.h"
#include "TFT.h"
#include "TFT_Touchscreen.h"

typedef struct {
	uint16_t x; //top-left corner x coordinate
	uint16_t y; //top-left corner y coordinate
	uint16_t width; // width of the button
	uint16_t height; // height of the button
	uint16_t bgcolor; // background color
	uint16_t fgcolor; // foreground color
	char label[10]; // label text
} Button;

void check_button(void);
void Back_button(void);
uint8_t Is_Button_Pressed(Button *btn, uint16_t touch_X, uint16_t touch_Y);
void Draw_Multiple_Button(void);
void Draw_Button(Button *btn);
void Test_Read_Coordinates(void);
void Basic_test(void);
void SerialWrite(char *uart2Data);
void DrawMainPage(void);
void DrawSecondPage(void);
void SerialRead(uint8_t *buffer, uint8_t len);
void HandleTouch(void);

#endif /* BUTTON_H_ */
