/*
 * TFT.h
 *
 *  Created on: Aug 12, 2024
 *      Author: kishan.shivhare
 */

#ifndef INC_TFT_H_
#define INC_TFT_H_

#include "stm32f1xx_hal.h"
extern SPI_HandleTypeDef hspi2;

#define LCD_hEIGHT 240
#define LCD_wIDTH 320
//#define LCD_hEIGHT  320
//#define LCD_wIDTH 240
#define TFT_CS_PIN GPIO_PIN_12
#define TFT_CS_PORT GPIOB
#define TFT_DC_PIN GPIO_PIN_1
#define TFT_DC_PORT GPIOB
#define TFT_RST_PIN GPIO_PIN_0
#define TFT_RST_PORT GPIOB

#define TFT_CS_LOW() HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_RESET)
#define TFT_CS_HIGH() HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_SET)
#define TFT_DC_LOW() HAL_GPIO_WritePin(TFT_DC_PORT, TFT_DC_PIN, GPIO_PIN_RESET)
#define TFT_DC_HIGH() HAL_GPIO_WritePin(TFT_DC_PORT, TFT_DC_PIN, GPIO_PIN_SET)
#define TFT_RST_LOW() HAL_GPIO_WritePin(TFT_RST_PORT, TFT_RST_PIN, GPIO_PIN_RESET)
#define TFT_RST_HIGH() HAL_GPIO_WritePin(TFT_RST_PORT, TFT_RST_PIN, GPIO_PIN_SET)

#define TFT_Enable() HAL_GPIO_WritePin(TFT_RST_PORT, TFT_RST_PIN, GPIO_PIN_SET)

#define ST77XX_BLACK 0X0000
#define ST77XX_WHITE 0XFFFF
#define ST77XX_RED 0XF800
#define ST77XX_GREEN 0X07E0
#define ST77XX_BLUE 0X001F

typedef uint16_t colour_t;

// colour bit layout rrrr rggg gggb bbbb
#define BLACK 						((colour_t)0x0000)
#define YELLOW 						((colour_t)0xffe0)
#define RED 						((colour_t)0xf800)
#define GREEN 						((colour_t)0x07e0)
#define BLUE 						((colour_t)0x001f)
#define WHITE 						((colour_t)0xffff)
#define PINK 						((colour_t)0xf80e)
#define PURPLE 						((colour_t)0xf83f)
#define	GREY15						((colour_t)0x1082)
#define	GREY14						((colour_t)0x2104)
#define	GREY13						((colour_t)0x3186)
#define	GREY12						((colour_t)0x4208)
#define	GREY11						((colour_t)0x528a)
#define	GREY10						((colour_t)0x630c)
#define	GREY9						((colour_t)0x738e)
#define	GREY8						((colour_t)0x8410)
#define	GREY7						((colour_t)0x9492)
#define	GREY6						((colour_t)0xa514)
#define	GREY5						((colour_t)0xb596)
#define	GREY4						((colour_t)0xc618)
#define	GREY3						((colour_t)0xd69a)
#define	GREY2						((colour_t)0xe71c)
#define	GREY1						((colour_t)0xf79e)
#define ORANGE 						((colour_t)0xfb80)
#define CYAN						((colour_t)0x07ff)
#define DARK_CYAN					((colour_t)0x0492)
#define LIGHT_ORANGE				((colour_t)0xfe20)
#define BRICK_RED					((colour_t)0xb104)


#define SCREEN_VERTICAL_1		0
#define SCREEN_HORIZONTAL_1		1
#define SCREEN_VERTICAL_2		2
#define SCREEN_HORIZONTAL_2		3

#define BURST_MAX_SIZE 	500

void TFT_Reset();
void TFT_init();
void TFT_SendCommand(uint8_t cmd);
void TFT_SendData(uint8_t data);
void TFT_FillScreen(uint16_t color);
void TFT_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
void ILI9341Pixel(uint16_t x, uint16_t y, colour_t colour);
void TFT_DrawPixel(uint16_t x, uint16_t y, uint16_t color);
void TFT_DrawPixel_image(uint16_t x, uint16_t y, uint16_t color);
void TFT_SetRotation(uint8_t rotation);
void TFT_FillRectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height,
		uint16_t color);
void TFT_DrawChar(char ch, const uint8_t font[], uint16_t x, uint16_t y,
		uint16_t color, uint16_t BG_color);
void TFT_DrawString(const char *str, const uint8_t font[], uint16_t x,
		uint16_t y, uint16_t color, uint16_t BG_color);

void TFT_Draw_Filled_Circle(uint16_t X, uint16_t Y, uint16_t Radius,
		uint16_t Colour);
void TFT_Filled_Rectangle_Coord(uint16_t X0, uint16_t Y0, uint16_t X1, uint16_t Y1, uint16_t Colour);
void TFT_Colour_Burst(uint16_t Colour, uint32_t Size);
#endif /* INC_TFT_H_ */
