/*
 * TFT_Touchscreen.h
 *
 *  Created on: Aug 13, 2024
 *      Author: kishan.shivhare
 */

#ifndef INC_TFT_TOUCHSCREEN_H_
#define INC_TFT_TOUCHSCREEN_H_

#include "stm32f1xx_hal.h"

#define TP_CS_PORT								GPIOA
#define TP_CS_PIN								GPIO_PIN_8

#define TP_MOSI_PORT							GPIOA
#define TP_MOSI_PIN								GPIO_PIN_9

#define TP_MISO_PORT							GPIOA
#define TP_MISO_PIN								GPIO_PIN_10

#define TP_CLK_PORT								GPIOA
#define TP_CLK_PIN								GPIO_PIN_11

#define TP_IRQ_PORT								GPIOA
#define TP_IRQ_PIN								GPIO_PIN_12

#define CMD_RDY             			0X90
#define CMD_RDX             			0XD0

#define TP_CS_LOW()  HAL_GPIO_WritePin(TP_CS_PORT, TP_CS_PIN, RESET)
#define TP_CS_HIGH()  HAL_GPIO_WritePin(TP_CS_PORT, TP_CS_PIN, SET)
#define TP_IRQ_LOW()  HAL_GPIO_WritePin(TP_IRQ_PORT, TP_IRQ_PIN, RESET)
#define TP_IRQ_HIGH()  HAL_GPIO_WritePin(TP_IRQ_PORT, TP_IRQ_PIN, SET)
//RETURN VALUES FOR TP_Touchpad_Pressed
#define TOUCHPAD_NOT_PRESSED			0
#define TOUCHPAD_PRESSED					1

//RETURN VALUES FOR TP_Read_Coordinates
#define TOUCHPAD_DATA_OK					1
#define TOUCHPAD_DATA_NOISY				0

//HARDCODED CALIBRATION, CHANGE IF REQUIRED
#define X_OFFSET									13
#define Y_OFFSET									15
#define X_MAGNITUDE								1.16
#define Y_MAGNITUDE								1.16

//CONVERTING 16bit Value to Screen coordinates
// 65535/273 = 240!
// 65535/204 = 320!
#define X_TRANSLATION							273
#define Y_TRANSLATION							204

//In order to increase accuracy of location reads library samples
//NO_OF_POSITION_SAMPLES numbers of locations and averages them
//If library runs too slow decrease NO_OF_POSITION_SAMPLES, but
//expect inreasingly noisy or incorrect locations returned

#define NO_OF_POSITION_SAMPLES	 	1000

#define RAWX_MIN 3000
#define RAWX_MAX 62500
#define RAWY_MIN 6000
#define RAWY_MAX 62500
#define DISPLAY_WIDTH 240
#define DISPLAY_HEIGHT 320

//Internal Touchpad command, do not call directly
uint16_t TP_Read(void);

//Internal Touchpad command, do not call directly
void TP_Write(uint8_t value);

//Read coordinates of touchscreen press. Position[0] = X, Position[1] = Y
uint8_t TP_Read_Coordinates(uint16_t Coordinates[2]);

//Check if Touchpad was pressed. Returns TOUCHPAD_PRESSED (1) or TOUCHPAD_NOT_PRESSED (0)
uint8_t TP_Touchpad_Pressed(void);

uint16_t Convert_to_DisplayX(uint16_t rawx) ;
uint16_t Convert_to_DisplayY(uint16_t rawy);
uint16_t Read_X(void);
uint16_t Read_Y(void);
void Read_Coordinates(uint16_t Coordinates[2]);
#endif /* INC_TFT_TOUCHSCREEN_H_ */
