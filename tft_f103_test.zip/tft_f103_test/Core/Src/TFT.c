/*
 * TFT.c
 *
 *  Created on: Aug 12, 2024
 *      Author: kishan.shivhare
 */
#include"TFT.h"


volatile uint16_t LCD_HEIGHT = LCD_hEIGHT;
volatile uint16_t LCD_WIDTH = LCD_wIDTH;

void TFT_Reset() {
	TFT_RST_LOW();
	HAL_Delay(10);
	TFT_RST_HIGH();
	HAL_Delay(100);
}
void TFT_init() {
	TFT_Enable();
	TFT_Reset();
	TFT_SendCommand(0x01); //software reset
	HAL_Delay(10);

	TFT_SendCommand(0xCB);
	TFT_SendData(0x39);
	TFT_SendData(0x2C);
	TFT_SendData(0x00);
	TFT_SendData(0x34);
	TFT_SendData(0x02);

	//POWER CONTROL B
	TFT_SendCommand(0xCF);
	TFT_SendData(0x00);
	TFT_SendData(0xC1);
	TFT_SendData(0x30);

	//DRIVER TIMING CONTROL A
	TFT_SendCommand(0xE8);
	TFT_SendData(0x85);
	TFT_SendData(0x00);
	TFT_SendData(0x78);

	//DRIVER TIMING CONTROL B
	TFT_SendCommand(0xEA);
	TFT_SendData(0x00);
	TFT_SendData(0x00);

	//POWER ON SEQUENCE CONTROL
	TFT_SendCommand(0xED);
	TFT_SendData(0x64);
	TFT_SendData(0x03);
	TFT_SendData(0x12);
	TFT_SendData(0x81);

	//PUMP RATIO CONTROL
	TFT_SendCommand(0xF7);
	TFT_SendData(0x20);

	//POWER CONTROL,VRH[5:0]
	TFT_SendCommand(0xC0);
	TFT_SendData(0x23);

	//POWER CONTROL,SAP[2:0];BT[3:0]
	TFT_SendCommand(0xC1);
	TFT_SendData(0x10);

	//VCM CONTROL
	TFT_SendCommand(0xC5);
	TFT_SendData(0x3E);
	TFT_SendData(0x28);

	//VCM CONTROL 2
	TFT_SendCommand(0xC7);
	TFT_SendData(0x86);

	//MEMORY ACCESS CONTROL
	TFT_SendCommand(0x36);
	TFT_SendData(0x48);

	//PIXEL FORMAT
	TFT_SendCommand(0x3A);
	TFT_SendData(0x55);

	//FRAME RATIO CONTROL, STANDARD RGB COLOR
	TFT_SendCommand(0xB1);
	TFT_SendData(0x00);
	TFT_SendData(0x18);

	//DISPLAY FUNCTION CONTROL
	TFT_SendCommand(0xB6);
	TFT_SendData(0x08);
	TFT_SendData(0x82);
	TFT_SendData(0x27);

	//3GAMMA FUNCTION DISABLE
	TFT_SendCommand(0xF2);
	TFT_SendData(0x00);

	//GAMMA CURVE SELECTED
	TFT_SendCommand(0x26);
	TFT_SendData(0x01);

	//POSITIVE GAMMA CORRECTION
	TFT_SendCommand(0xE0);
	TFT_SendData(0x0F);
	TFT_SendData(0x31);
	TFT_SendData(0x2B);
	TFT_SendData(0x0C);
	TFT_SendData(0x0E);
	TFT_SendData(0x08);
	TFT_SendData(0x4E);
	TFT_SendData(0xF1);
	TFT_SendData(0x37);
	TFT_SendData(0x07);
	TFT_SendData(0x10);
	TFT_SendData(0x03);
	TFT_SendData(0x0E);
	TFT_SendData(0x09);
	TFT_SendData(0x00);

	//NEGATIVE GAMMA CORRECTION
	TFT_SendCommand(0xE1);
	TFT_SendData(0x00);
	TFT_SendData(0x0E);
	TFT_SendData(0x14);
	TFT_SendData(0x03);
	TFT_SendData(0x11);
	TFT_SendData(0x07);
	TFT_SendData(0x31);
	TFT_SendData(0xC1);
	TFT_SendData(0x48);
	TFT_SendData(0x08);
	TFT_SendData(0x0F);
	TFT_SendData(0x0C);
	TFT_SendData(0x31);
	TFT_SendData(0x36);
	TFT_SendData(0x0F);

	//EXIT SLEEP
	TFT_SendCommand(0x11);
	HAL_Delay(100);

	//TURN ON DISPLAY
	TFT_SendCommand(0x29);

	//STARTING ROTATION
	TFT_SetRotation(SCREEN_VERTICAL_2);
//	TFT_SetRotation(SCREEN_HORIZONTAL_1);
//	TFT_SendCommand(0x11); //sleep out
//	HAL_Delay(100);
//	TFT_SendCommand(0x36); //memory data access
//	HAL_Delay(100);
//	TFT_SendData(0x00); //set the orientation
//	TFT_SendCommand(0x3A); //interface pixel format
//	TFT_SendData(0x55); ////16 bit/pixel
//	TFT_SendCommand(0x29); //Display on
//	TFT_SetRotation(SCREEN_HORIZONTAL_1);
}
void TFT_SendCommand(uint8_t cmd) {
	TFT_DC_LOW();
	TFT_CS_LOW();
	HAL_SPI_Transmit(&hspi2, &cmd, 1, HAL_MAX_DELAY);
	TFT_CS_HIGH();

}
void TFT_SendData(uint8_t data) {
	TFT_DC_HIGH();
	TFT_CS_LOW();
	HAL_SPI_Transmit(&hspi2, &data, 1, HAL_MAX_DELAY);
	TFT_CS_HIGH();
}
void TFT_FillScreen(uint16_t color) {
	TFT_SetAddressWindow(0, 0, LCD_WIDTH - 1, LCD_HEIGHT - 1);
	TFT_Colour_Burst(color, LCD_HEIGHT*LCD_WIDTH);
//	uint8_t data[2] = { color >> 8, color & 0xFF };
//	TFT_DC_HIGH();
//	TFT_CS_LOW();
//	for (uint32_t i = 0; i < LCD_WIDTH * LCD_HEIGHT; i++) {
//		HAL_SPI_Transmit(&hspi1, data, 2, HAL_MAX_DELAY);
//	}
//	TFT_CS_HIGH();
}
void TFT_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
	TFT_SendCommand(0x2A); // column address set
	TFT_SendData(x0 >> 8);
	TFT_SendData(x0 & 0xFF);
	TFT_SendData(x1 >> 8);
	TFT_SendData(x1 & 0xFF);

	TFT_SendCommand(0x2B); // row address set
	TFT_SendData(y0 >> 8);
	TFT_SendData(y0 & 0xFF);
	TFT_SendData(y1 >> 8);
	TFT_SendData(y1 & 0xFF);

	TFT_SendCommand(0x2C); //memory write
}
void ILI9341Pixel(uint16_t x, uint16_t y, colour_t colour)
{
	colour_t beColour = __builtin_bswap16(colour);
//
//	if (x >= ILI9341_LCD_WIDTH || y >= ILI9341_LCD_HEIGHT)
//	{
//		return;
//	}
//
	TFT_SetAddressWindow(x, y, x + 1, y + 1);

	HAL_SPI_Transmit(&hspi2, (uint8_t *)&beColour, 2U, 100UL);
}
void TFT_DrawPixel_image(uint16_t x, uint16_t y, colour_t colour) {
	if ((x >= LCD_WIDTH) || (y >= LCD_HEIGHT))
		return;
	//TFT_SetAddressWindow(x, y, x + 1, y + 1);
	uint8_t data[2] = { colour >> 8, colour & 0xFF };
	TFT_DC_HIGH();
	TFT_CS_LOW();
	HAL_SPI_Transmit(&hspi2, data, 2, 100UL);
	TFT_CS_HIGH();
}

void TFT_DrawPixel(uint16_t x, uint16_t y, uint16_t color) {
	if ((x >= LCD_WIDTH) || (y >= LCD_HEIGHT))
		return;
	TFT_SetAddressWindow(x, y, x + 1, y + 1);
	uint8_t data[2] = { color >> 8, color & 0xFF };
	TFT_DC_HIGH();
	TFT_CS_LOW();
	HAL_SPI_Transmit(&hspi2, data, 2, 100);
	TFT_CS_HIGH();
}
void TFT_SetRotation(uint8_t rotation) {
	TFT_SendCommand(0x36);
	HAL_Delay(1);

	switch (rotation) {
	case SCREEN_VERTICAL_1:
		TFT_SendData(0x40 | 0x08);
		LCD_WIDTH = 240;
		LCD_HEIGHT = 320;
		break;
	case SCREEN_HORIZONTAL_1:
		TFT_SendData(0x20 | 0x08);
		LCD_WIDTH = 320;
		LCD_HEIGHT = 240;
		break;
	case SCREEN_VERTICAL_2:
		TFT_SendData(0x80 | 0x08);
		LCD_WIDTH = 240;
		LCD_HEIGHT = 320;
		break;
	case SCREEN_HORIZONTAL_2:
		TFT_SendData(0x40 | 0x80 | 0x20 | 0x08);
		LCD_WIDTH = 320;
		LCD_HEIGHT = 240;
		break;
	default:
		break;
	}
}
void TFT_Colour_Burst(uint16_t Colour, uint32_t Size)
{
//SENDS COLOUR
uint32_t Buffer_Size = 0;
if((Size*2) < BURST_MAX_SIZE)
{
	Buffer_Size = Size;
}
else
{
	Buffer_Size = BURST_MAX_SIZE;
}
	TFT_DC_HIGH();
	TFT_CS_LOW();



unsigned char chifted = 	Colour>>8;;
unsigned char burst_buffer[Buffer_Size];
for(uint32_t j = 0; j < Buffer_Size; j+=2)
	{
		burst_buffer[j] = 	chifted;
		burst_buffer[j+1] = Colour;
	}

uint32_t Sending_Size = Size*2;
uint32_t Sending_in_Block = Sending_Size/Buffer_Size;
uint32_t Remainder_from_block = Sending_Size%Buffer_Size;

if(Sending_in_Block != 0)
{
	for(uint32_t j = 0; j < (Sending_in_Block); j++)
		{
		HAL_SPI_Transmit(&hspi2, (unsigned char *)burst_buffer, Buffer_Size, 10);
		}
}

//REMAINDER!
HAL_SPI_Transmit(&hspi2, (unsigned char *)burst_buffer, Remainder_from_block, 10);
TFT_CS_HIGH();

}
void TFT_Filled_Rectangle_Coord(uint16_t X0, uint16_t Y0, uint16_t X1, uint16_t Y1, uint16_t Colour)
{
	uint16_t 	X_length = 0;
	uint16_t 	Y_length = 0;
	uint8_t		Negative_X = 0;
	uint8_t 	Negative_Y = 0;
	int32_t 	Calc_Negative = 0;

	uint16_t X0_true = 0;
	uint16_t Y0_true = 0;

	Calc_Negative = X1 - X0;
	if(Calc_Negative < 0) Negative_X = 1;
	Calc_Negative = 0;

	Calc_Negative = Y1 - Y0;
	if(Calc_Negative < 0) Negative_Y = 1;


	//DRAW HORIZONTAL!
	if(!Negative_X)
	{
		X_length = X1 - X0;
		X0_true = X0;
	}
	else
	{
		X_length = X0 - X1;
		X0_true = X1;
	}

	//DRAW VERTICAL!
	if(!Negative_Y)
	{
		Y_length = Y1 - Y0;
		Y0_true = Y0;
	}
	else
	{
		Y_length = Y0 - Y1;
		Y0_true = Y1;
	}

	TFT_FillRectangle(X0_true, Y0_true, X_length, Y_length, Colour);
}
void TFT_FillRectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height,
		uint16_t color) {
	if ((x >= LCD_WIDTH) || (y >= LCD_HEIGHT))
		return;
	if ((x + width - 1) >= LCD_WIDTH)
		width = LCD_WIDTH - x;
	if ((y + height - 1) >= LCD_HEIGHT)
		height = LCD_HEIGHT - y;

	TFT_SetAddressWindow(x, y, x + width - 1, y + height - 1);
	TFT_Colour_Burst(color, height*width);
//	uint8_t data[2] = { color >> 8, color & 0xFF };
//
//	TFT_CS_LOW();
//	TFT_DC_HIGH();
//
//	for (uint8_t i = 0; i < (width * height); i++) {
//		HAL_SPI_Transmit(&hspi1, data, 2, HAL_MAX_DELAY);
//	}
//	TFT_CS_HIGH();

}
void TFT_DrawChar(char ch, const uint8_t font[], uint16_t x, uint16_t y,
		uint16_t color, uint16_t BG_color) {
	if ((ch < 31) || (ch > 127))
		return;
	uint8_t foffset, fwidth, fheight, fbpl;
	uint8_t *tempchar;
	foffset = font[0];
	fwidth = font[1];
	fheight = font[2];
	fbpl = font[3];

	tempchar = (uint8_t*) &font[((ch - 0x20) * foffset) + 4];
	TFT_FillRectangle(x, y, fwidth, fheight, BG_color);

	for (int j = 0; j < fheight; j++) {
		for (int i = 0; i < fwidth; i++) {
			uint8_t z = tempchar[fbpl * i + ((j & 0xF8) >> 3) + 1]; /* (j & 0xF8) >> 3, increase one by 8-bits */
			uint8_t b = 1 << (j & 0x07);
			if ((z & b) != 0x00) {
				TFT_DrawPixel(x + i, y + j, color);
			}
		}
	}
}

void TFT_DrawString(const char *str, const uint8_t font[], uint16_t x,
		uint16_t y, uint16_t color, uint16_t BG_color) {
	uint8_t charWidth; /* Width of character */
	uint8_t fOffset = font[0]; /* Offset of character */
	uint8_t fWidth = font[1]; /* Width of font */

	while (*str) {
		TFT_DrawChar(*str, font, x, y, color, BG_color);

		/* Check character width and calculate proper position */
		uint8_t *tempChar = (uint8_t*) &font[((*str - 0x20) * fOffset) + 4];
		charWidth = tempChar[0];

		if (charWidth + 2 < fWidth) {
			/* If character width is smaller than font width */
			x += (charWidth + 2);
		} else {
			x += fWidth;
		}

		str++;
	}
}

void TFT_Draw_Filled_Circle(uint16_t X, uint16_t Y, uint16_t Radius,
		uint16_t Colour) {

	int x = Radius;
	int y = 0;
	int xChange = 1 - (Radius << 1);
	int yChange = 0;
	int radiusError = 0;

	while (x >= y) {
		for (int i = X - x; i <= X + x; i++) {
			TFT_DrawPixel(i, Y + y, Colour);
			TFT_DrawPixel(i, Y - y, Colour);
		}
		for (int i = X - y; i <= X + y; i++) {
			TFT_DrawPixel(i, Y + x, Colour);
			TFT_DrawPixel(i, Y - x, Colour);
		}

		y++;
		radiusError += yChange;
		yChange += 2;
		if (((radiusError << 1) + xChange) > 0) {
			x--;
			radiusError += xChange;
			xChange += 2;
		}
	}
	//Really slow implementation, will require future overhaul
	//TODO:	https://stackoverflow.com/questions/1201200/fast-algorithm-for-drawing-filled-circles
}
