/*
 * button.h
 *
 *  Created on: Sep 9, 2024
 *      Author: kishan.shivhare
 */
#include "button.h"
#include <string.h>
#include <stdio.h>
#include "stm32f1xx_hal.h"
int i = 0;
uint16_t coordinates[2];

typedef enum {
	PAGE_MAIN, PAGE_SECOND,
} page;
page currentPage = PAGE_MAIN;

Button button1 = { 10, 30, 100, 50, ST77XX_RED, ST77XX_WHITE, "60" };
Button button2 = { 130, 30, 100, 50, ST77XX_BLUE, ST77XX_WHITE, "40" };
Button button3 = { 10, 90, 100, 50, ST77XX_RED, ST77XX_WHITE, "70" };
Button button4 = { 130, 90, 100, 50, ST77XX_BLUE, ST77XX_WHITE, "30" };
Button button5 = { 10, 150, 100, 50, ST77XX_RED, ST77XX_WHITE, "80" };
Button button6 = { 130, 150, 100, 50, ST77XX_BLUE, ST77XX_WHITE, "20" };
Button button7 = { 10, 210, 100, 50, ST77XX_RED, ST77XX_WHITE, "-40" };
Button button8 = { 130, 210, 100, 50, ST77XX_BLUE, ST77XX_WHITE, "40" };
Button button9 = { 75, 270, 100, 40, ST77XX_GREEN, ST77XX_BLACK, "50" };
Button button10 = { 130, 270, 100, 50, ST77XX_BLUE, ST77XX_WHITE, "Button10" };
Button Back = { 130, 250, 100, 50, ST77XX_BLUE, ST77XX_WHITE, "Back" };

extern UART_HandleTypeDef huart2;

void DrawMainPage(void) {
	TFT_FillScreen(ST77XX_WHITE);
	TFT_DrawString("LEFT", FONT3, 40, 10, ST77XX_BLACK, ST77XX_WHITE);
	TFT_DrawString("RIGHT", FONT3, 160, 10, ST77XX_BLACK, ST77XX_WHITE);
	Draw_Multiple_Button();
	//Draw_Button(&button1);
	TFT_DrawString("MAIN", FONT3, 10, 300, ST77XX_BLACK,
	ST77XX_WHITE);
}
void DrawSecondPage(void) {
	TFT_FillScreen(ST77XX_WHITE);
	Draw_Button(&Back);
	TFT_DrawString("Second PAGE", FONT3, 10, 100, ST77XX_BLACK,
	ST77XX_WHITE);
}
void HandleTouch(void) {
	uint16_t touchX, touchY;
	if (TP_Touchpad_Pressed()) {

		Read_Coordinates(coordinates);
		touchX = coordinates[0];
		touchY = coordinates[1];
		if (currentPage == PAGE_MAIN) {
			check_button();

		} else if (currentPage == PAGE_SECOND) {

			if (Is_Button_Pressed(&Back, touchX, touchY)) {
				currentPage = PAGE_MAIN;
				DrawMainPage();

			}
		}
	}
}
void Basic_test(void) {
	TFT_FillScreen(ST77XX_WHITE);
	TFT_DrawString("Hello", FONT3, 100, 100, ST77XX_BLUE, ST77XX_BLACK);
	TFT_FillScreen(ST77XX_BLUE);
	TFT_DrawChar('A', FONT3, 10, 10, ST77XX_WHITE, ST77XX_BLACK);
	HAL_Delay(100);
	TFT_DrawPixel(120, 170, ST77XX_GREEN);
	//TFT_FillRectangle(0, 0, 200, 120, ST77XX_GREEN);
	TFT_Filled_Rectangle_Coord(0, 0, 200, 120, ST77XX_GREEN);
	TFT_FillScreen(ST77XX_WHITE);
	//TFT_SetRotation(SCREEN_HORIZONTAL_2);
	TFT_DrawString("Touchscreen", FONT3, 10, 10, ST77XX_BLACK, ST77XX_WHITE);
	TFT_DrawString("Touch to draw", FONT3, 10, 30, ST77XX_BLACK, ST77XX_WHITE);
	//TFT_SetRotation(SCREEN_VERTICAL_2);
}
void Test_Read_Coordinates(void) {
	uint16_t x = Read_X();
	uint16_t y = Read_Y();
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);

	//TFT_Draw_Filled_Circle(x, y, 2, ST77XX_BLACK);

	//	TFT_SetRotation(SCREEN_HORIZONTAL_2);
	char counter_buff[30];
	sprintf(counter_buff, "POS X: %d", x);
	TFT_DrawString(counter_buff, FONT3, 10, 180, ST77XX_BLACK,
	ST77XX_WHITE);
	sprintf(counter_buff, "POS Y: %d", y);
	TFT_DrawString(counter_buff, FONT3, 10, 220, ST77XX_BLACK,
	ST77XX_WHITE);
	// Print or debug the values of x and y here
}
void Draw_Button(Button *btn) {
	//draw the buttomn background
	TFT_FillRectangle(btn->x, btn->y, btn->width, btn->height, btn->bgcolor);
	//draw the button label text centered
	uint16_t text_x = btn->x + (btn->width / 2) - (strlen(btn->label) * 6 / 2); //Adjust the label position
	uint16_t text_y = btn->y + (btn->height / 2) - 8; //Adjust the label position
	TFT_DrawString(btn->label, FONT4, text_x, text_y, btn->fgcolor,
			btn->bgcolor);
}

void Draw_Multiple_Button(void) {
	Draw_Button(&button1);
	Draw_Button(&button2);
	Draw_Button(&button3);
	Draw_Button(&button4);
	Draw_Button(&button5);
	Draw_Button(&button6);
//	Draw_Button(&button7);
//	Draw_Button(&button8);
	Draw_Button(&button9);
//	Draw_Button(&button10);

}
uint8_t Is_Button_Pressed(Button *btn, uint16_t touch_X, uint16_t touch_Y) {
	if (touch_X >= btn->x && touch_X <= (btn->x + btn->width)
			&& touch_Y >= btn->y + 5 && touch_Y <= (btn->y + 5 + btn->height)) {
		return 1;

	}
	return 0;

}

void Back_button(void) {
	Draw_Button(&Back);
	while (!TP_Touchpad_Pressed()) {
		i++;
	}

	do {
		Read_Coordinates(coordinates);
	} while (!Is_Button_Pressed(&Back, coordinates[0], coordinates[1]));

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
	TFT_FillScreen(ST77XX_WHITE);
	Draw_Multiple_Button();

}

void check_button(void) {
	if (Is_Button_Pressed(&button1, coordinates[0], coordinates[1])) {
		//HAL_UART_Transmit_IT(&huart1, "60", 2);
		SerialWrite("60");
		TFT_FillScreen(ST77XX_WHITE);
		currentPage = PAGE_SECOND;
		DrawSecondPage();

		TFT_DrawString("60 is sent", FONT4, 10, 10, ST77XX_BLACK,
		ST77XX_WHITE);

	} else if (Is_Button_Pressed(&button2, coordinates[0], coordinates[1])) {
		SerialWrite("40");
		currentPage = PAGE_SECOND;

		DrawSecondPage();
		TFT_DrawString("40 is sent", FONT4, 10, 10, ST77XX_BLACK,
		ST77XX_WHITE);
	} else if (Is_Button_Pressed(&button3, coordinates[0], coordinates[1])) {
	SerialWrite("70");
		currentPage = PAGE_SECOND;
		DrawSecondPage();
		TFT_DrawString("70 is sent", FONT4, 10, 10, ST77XX_BLACK,
		ST77XX_WHITE);

	} else if (Is_Button_Pressed(&button4, coordinates[0], coordinates[1])) {
		SerialWrite("30");
		currentPage = PAGE_SECOND;
		DrawSecondPage();
		TFT_DrawString("30 is sent", FONT4, 10, 10, ST77XX_BLACK,
		ST77XX_WHITE);

	} else if (Is_Button_Pressed(&button5, coordinates[0], coordinates[1])) {
		SerialWrite("80");
		currentPage = PAGE_SECOND;
		DrawSecondPage();
		TFT_DrawString("80 is sent", FONT4, 10, 10, ST77XX_BLACK,
		ST77XX_WHITE);

	} else if (Is_Button_Pressed(&button6, coordinates[0], coordinates[1])) {
		SerialWrite("20");
		currentPage = PAGE_SECOND;
		DrawSecondPage();
		TFT_DrawString("20 is sent", FONT4, 10, 10, ST77XX_BLACK,
		ST77XX_WHITE);

	}
//	else if (Is_Button_Pressed(&button7, coordinates[0], coordinates[1])) {
//		SerialWrite("-40");
//		currentPage = PAGE_SECOND;
//		DrawSecondPage();
//		TFT_DrawString("-40 is sent", FONT4, 10, 10, ST77XX_BLACK,
//		ST77XX_WHITE);
//
//	} else if (Is_Button_Pressed(&button8, coordinates[0], coordinates[1])) {
//		SerialWrite("40");
//		currentPage = PAGE_SECOND;
//		DrawSecondPage();
//		TFT_DrawString("40 is sent", FONT4, 10, 10, ST77XX_BLACK,
//		ST77XX_WHITE);
	//}
else if (Is_Button_Pressed(&button9, coordinates[0], coordinates[1])) {
		SerialWrite("50");
		currentPage = PAGE_SECOND;
		DrawSecondPage();
		TFT_DrawString("50 is sent", FONT4, 10, 10, ST77XX_BLACK,
		ST77XX_WHITE);

	}
	//else if (Is_Button_Pressed(&button10, coordinates[0],
	//					coordinates[1])) {
	//				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
	//				TFT_FillScreen(ST77XX_WHITE);
	//				TFT_DrawString("Button 10 Pressed", FONT4, 10, 10, ST77XX_BLACK,
	//				ST77XX_WHITE);
	//				Back_button();
	//			}
}

void SerialWrite(char *uart2Data) {

	HAL_StatusTypeDef uart_status;

	uart_status = HAL_UART_Transmit(&huart2, (uint8_t*) uart2Data,
			strlen(uart2Data), 1000);

	if (uart_status != HAL_OK)

	{

		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);

		HAL_Delay(1000);

	}

}
void SerialRead(uint8_t *buffer, uint8_t len){
	HAL_UART_Receive(&huart2, buffer, len, HAL_MAX_DELAY);
}

